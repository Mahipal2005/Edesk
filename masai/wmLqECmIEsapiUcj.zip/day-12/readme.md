- CRUD => create , read , update , delete
           (POST)  (GET)  (PATCH)   (DELETE)

- read => reading and iteration over the data
- 
fetch(url , {
    method : POST
})