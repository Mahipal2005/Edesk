
const  fs = require("fs")
const validationMiddleware = (req,res,next)=>{
    const {ID,Name,Rating,Description,Genre,Cast} = req.body
    if(!ID || !Name||!Rating||!Description||!Genre||!Cast){
        res.status(400).json({'message':"Invalid Data Found"})
        return
    }

    let err = ""
    let checkID = typeof(ID)=="number"
    if(!checkID){
        err+= `Invalid ID type \n`
        fs.appendFileSync("./res.txt", err)
        res.status(400).json({'message': err})
        return
    }

    let checkName = typeof(Name)=="string"
    if(!checkName){
        err+= `Invalid Name type \n`
    }
    let checkRating = typeof(Rating)=="number"
    let checkDescription = typeof(Description)=="string"
    let checkGenre = typeof(Genre)=="string"
    // Checks whether an element is even
    const checkString = (element) => typeof(element) == "string";
    let checkCast = Array.isArray(Cast) && Cast.some(checkString)
    console.log("line no 18",checkCast)

    if(checkID && checkName && checkRating && checkDescription && checkGenre && checkCast){
        next()
    }else{
        
        res.status(400).json({'message':"Some Input is not in right format, please check all credentials"})
    }
   
      
}

module.exports = validationMiddleware
