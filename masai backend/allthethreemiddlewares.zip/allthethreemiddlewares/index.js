const express = require("express");
const fs = require("fs");
const validationMiddleware = require("./middlewares/validation.middleware");
const limiter = require("./middlewares/rate.limiter");
const app = express()
app.use(express.json())  // this is inbuilt middleware

app.use(limiter)  // this is 3rd party middleware, created by others available in npm

app.post("/",validationMiddleware, (req,res)=>{  // validationMiddleware is custom middleware created by us
    res.status(201).json({'message':"Data Received"})
})


app.listen(8080, ()=>{
    console.log("server started")
})