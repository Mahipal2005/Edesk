const expres = require("express")
const userRoutes = expres.Router() 

userRoutes.post("/signup", (req,res)=>{
    console.log(req.body)
    res.send("Already Registered")
})
userRoutes.post("/login", (req,res)=>{
    console.log(req.body)
    res.send("Already Registered")
})
userRoutes.post("/deleteuser", (req,res)=>{
    console.log(req.body)
    res.send("Already Registered")
})

module.exports = userRoutes