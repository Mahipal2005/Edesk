const expres = require("express")
const todoRoutes = expres.Router() 


todoRoutes.get("/alltodos",(req,res)=>{
    console.log("from get", req.body)
    res.send("all todos")
})
todoRoutes.post("/addtodos",(req,res)=>{
    console.log("from get", req.body)
    res.send("all todos")
})
todoRoutes.delete("/deletetodos",(req,res)=>{
    console.log("from get", req.body)
    res.send("all todos")
})
module.exports=todoRoutes