const http = require("http")

const server = http.createServer( (req,res)=>{
    if(req.url=="/signup" && req.method=="POST"){/// this is request done by the user
        // It is backend logic
        // console.log(req.body)
        let body = "";
        req.on("data", (chunk) => {
          body += chunk.toString();
        });
        req.on("end", () => {
          const newData = JSON.parse(body)
          console.log(body)});
      
        res.end("Alreday Registered")  // Response
    } else if(req.url=="/login" && req.method=="POST"){
        let body = "";
        req.on("data", (chunk) => {
          body += chunk.toString();
        });
        req.on("end", () => {
          const newData = JSON.parse(body)
          console.log(body)});

    }else if(req.url=="/gettodos" && req.method=="GET"){

    }else if(req.url=="/addtodo" && req.method=="POST" ){
        
    }
    
    else{
        res.end("Please Signup")
    }
})


server.listen(8080,()=>{
    console.log("server started")
})



