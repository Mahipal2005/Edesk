const express = require("express");
const userRoutes = require("./routes/userroutes");
const todoRoutes = require("./routes/todoRoutes");
const app = express()
app.use(express.json())
app.use(express.text())

app.use("/users", userRoutes)
app.use("/todos", todoRoutes)

app.listen(8181,()=>{
    console.log("server started")
})